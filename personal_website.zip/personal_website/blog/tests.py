from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import Post


class BlogTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username="testuser",
            email="testuser@example.com",
            password="secret",
        )

        self.post = Post.objects.create(
            title="A good title",
            body="Nice body content",
            author=self.user,
        )

    def test_string_representation(self):
        post = Post(title="A sample title")
        self.assertEqual(str(post), post.title)

    def test_get_absolute_url(self):
        self.assertEqual(self.post.get_absolute_url(), f"/blog/post/{self.post.id}/")

    def test_post_content(self):
        self.assertEqual(f"{self.post.author}", "testuser")
        self.assertEqual(f"{self.post.title}", "A good title")
        self.assertEqual(f"{self.post.body}", "Nice body content")

    def test_post_list_view(self):
        response = self.client.get(reverse("blog:home"))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "A good title")
        self.assertTemplateUsed(response, "blog/home.html")

    def test_post_detail_view(self):
        response = self.client.get(self.post.get_absolute_url())
        no_response = self.client.get("/blog/post/100000/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(no_response.status_code, 404)
        self.assertContains(response, "A good title")
        self.assertTemplateUsed(response, "blog/post_detail.html")

    def test_post_createview(self):
        response = self.client.post(
            reverse("blog:post_new"),
            {
                "title": "New title",
                "body": "New text",
                "author": self.user.id,
            },
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Post.objects.last().title, "New title")
        self.assertEqual(Post.objects.last().body, "New text")

    def test_post_updateview(self):
        response = self.client.post(
            reverse("blog:post_edit", args=[self.post.pk]),
            {
                "title": "Updated title",
                "body": "Updated text",
                "author": self.user.id,
            },
        )
        self.assertEqual(response.status_code, 302)
        self.assertEqual(Post.objects.get(pk=self.post.pk).title, "Updated title")
        self.assertEqual(Post.objects.get(pk=self.post.pk).body, "Updated text")

    def test_post_deleteview(self):
        response = self.client.get(reverse("blog:post_delete", args=[self.post.pk]))
        self.assertEqual(response.status_code, 200)
